# OrangeDoorhinge

This is a team project for CS 451R - Software Engineering Capstone class at University of Missouri - Kansas City. The project follows requirements from Commerce Bank. 

Team Members:
Jared Lee,
Joe Parsa,
Eric Haynes,
Thuy Huynh.

Project Summary:
We will be creating a web application that allows users to log in and set up their own fundraisers, track their donations, and view and donate to other users’ fundraisers. We are able to track and make donations through your site (all data are fake/dummy card numbers when appropriate to simulate the process).

